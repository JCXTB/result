/**
 * Project Name: demo
 * File Name: TestController
 * Package Name: com.example.demo
 * Date: 2020/6/2 15:06
 * Author: 方瑞冬
 */
package com.example.demo.controller;

import com.example.demo.entity.User;
import com.example.demo.result.BaseRuntimeException;
import com.example.demo.result.Result;
import com.example.demo.result.ResultEnum;
import com.example.demo.result.ResultUtil;
import com.example.demo.service.TestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping("/test")
public class TestController {
    @Autowired
    private TestService testService;

    @GetMapping("/one")
    public Result<User> one() {
        return ResultUtil.successWithData(testService.getUser());
    }

    @GetMapping("/two")
    public Result<Object> two(){
        throw new BaseRuntimeException(ResultEnum.NOT_FOUND, "用户小明");
    }

    @GetMapping("/three")
    public Result<Object> three(){
        int a = 6/0;
        return ResultUtil.success();
    }
}
