/**
 * Project Name: demo
 * File Name: User
 * Package Name: com.example.demo
 * Date: 2020/6/2 15:16
 * Author: 方瑞冬
 */
package com.example.demo.entity;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class User {
    private String name;

    private Integer age;
}
