/**
 * Project Name: demo
 * File Name: Test
 * Package Name: com.example.demo
 * Date: 2020/6/2 15:52
 * Author: 方瑞冬
 */
package com.example.demo.result;

/**
 * @author 方瑞冬
 */
public interface BaseResultEnum {
    /**
     * 状态码
     */
    Integer code = null;

    /**
     * 消息
     */
    String message = null;

    /**
     * 是否成功
     */
    Boolean success = null;

    /**
     * 获取状态码
     */
    Integer getCode();

    /**
     * 获取消息
     */
    String getMessage();

    /**
     * 获取是否成功
     */
    Boolean getSuccess();
}
