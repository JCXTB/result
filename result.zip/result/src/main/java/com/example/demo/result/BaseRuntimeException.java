/**
 * Project Name: demo
 * File Name: BaseRuntimeException
 * Package Name: com.example.demo
 * Date: 2020/6/2 16:40
 * Author: 方瑞冬
 */
package com.example.demo.result;

import lombok.Getter;

import java.util.Formatter;

/**
 * @author 方瑞冬
 */
@Getter
public class BaseRuntimeException extends RuntimeException {
    /**
     * 异常返回
     */
    public Result<Object> result;

    /**
     * @author: 方瑞冬
     * @date: 2020/6/3 10:20
     * @since: JDK 1.8
     * 
     * @description: 异常无参构造
     * @param: [baseResultEnum]
     * @return: 
     */
    public BaseRuntimeException(BaseResultEnum baseResultEnum){
        this.result = new Result<>(baseResultEnum);
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/6/3 10:20
     * @since: JDK 1.8
     * 
     * @description: 异常带参构造
     * @param: [baseResultEnum, args]
     * @return: 
     */
    public BaseRuntimeException(BaseResultEnum baseResultEnum, Object... args){
        this.result = new Result<>(baseResultEnum);
        this.result.setMessage(new Formatter().format(baseResultEnum.getMessage(), args).toString());
    }
}
