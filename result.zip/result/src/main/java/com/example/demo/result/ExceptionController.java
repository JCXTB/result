/**
 * Project Name: demo
 * File Name: BaseExceptionController
 * Package Name: com.example.demo
 * Date: 2020/6/2 17:20
 * Author: 方瑞冬
 */
package com.example.demo.result;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author 方瑞冬
 */
@RestControllerAdvice
@Slf4j
public class ExceptionController {
    /**
     * @author: 方瑞冬
     * @date: 2020/6/3 10:18
     * @since: JDK 1.8
     * 
     * @description: 自定义异常捕获、记录、返回
     * @param: [baseRuntimeException]
     * @return: com.example.demo.result.Result<java.lang.Object>
     */
    @ExceptionHandler(value = BaseRuntimeException.class)
    public Result<Object> baseExceptionReturn(BaseRuntimeException baseRuntimeException){
        log.warn(baseRuntimeException.getResult().getMessage());
        return baseRuntimeException.getResult();
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/6/3 10:18
     * @since: JDK 1.8
     * 
     * @description: 未知异常捕获、记录、返回
     * @param: [e]
     * @return: com.example.demo.result.Result<java.lang.Object>
     */
    @ExceptionHandler(value = Exception.class)
    public Result<Object> exceptionReturn(Exception e){
        log.error(e.getMessage(), e);
        return ResultUtil.error();
    }
}
