/**
 * Project Name: demo
 * File Name: Result
 * Package Name: com.example.demo
 * Date: 2020/6/2 14:12
 * Author: 方瑞冬
 */
package com.example.demo.result;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author 方瑞冬
 */
@Data
@NoArgsConstructor
public class Result<T> implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 状态码
     */
    private Integer code;

    /**
     * 消息
     */
    private String message;

    /**
     * 数据
     */
    private T data;

    /**
     * 是否成功
     */
    private Boolean success;

    /**
     * 时间戳
     */
    private Long timestamp;

    /**
     * @author: 方瑞冬
     * @date: 2020/6/3 10:22
     * @since: JDK 1.8
     * 
     * @description: 返回枚举参数构造
     * @param: [baseResultEnum]
     * @return: 
     */
    public Result(BaseResultEnum baseResultEnum){
        this.code = baseResultEnum.getCode();
        this.message = baseResultEnum.getMessage();
        this.success = baseResultEnum.getSuccess();
        this.timestamp = System.currentTimeMillis();
    }
}
