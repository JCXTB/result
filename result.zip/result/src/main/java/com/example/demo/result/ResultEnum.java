/**
 * Project Name: demo
 * File Name: ReultEnum
 * Package Name: com.example.demo
 * Date: 2020/6/2 14:36
 * Author: 方瑞冬
 */
package com.example.demo.result;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author 方瑞冬
 */
@Getter
@AllArgsConstructor
public enum ResultEnum implements BaseResultEnum {
    SUCCESS(200, "请求成功", true),
    AUTH_FAILD(302, "获取登录用户失败", false),
    NOT_FOUND(404, "找不到%s", false),
    ERROR(500, "服务器错误", false);

    /**
     * 状态码
     */
    private final Integer code;

    /**
     * 消息
     */
    private final String message;

    /**
     * 是否成功
     */
    private final Boolean success;
}
