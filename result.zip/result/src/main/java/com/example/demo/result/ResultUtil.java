/**
 * Project Name: demo
 * File Name: ResultUtil
 * Package Name: com.example.demo
 * Date: 2020/6/2 14:26
 * Author: 方瑞冬
 */
package com.example.demo.result;

/**
 * @author 方瑞冬
 */
public class ResultUtil {
    /**
     * @author: 方瑞冬
     * @date: 2020/6/2 15:42
     * @since: JDK 1.8
     * 
     * @description: 默认成功返回
     * @param: []
     * @return: com.example.demo.result.Result<T>
     */
    public static<T> Result<T> success(){
       Result<T> result = new Result<>(ResultEnum.SUCCESS);
       result.setData(null);
       return result;
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/6/2 15:43
     * @since: JDK 1.8
     *
     * @description: 成功返回，自定义返回数据
     * @param: [data]
     * @return: com.example.demo.result.Result<T>
     */
    public static<T> Result<T> successWithData(T data){
        Result<T> result = new Result<>(ResultEnum.SUCCESS);
        result.setData(data);
        return result;
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/6/2 15:44
     * @since: JDK 1.8
     *
     * @description: 默认错误返回
     * @param: []
     * @return: com.example.demo.result.Result<T>
     */
    public static<T> Result<T> error(){
        Result<T> result = new Result<>(ResultEnum.ERROR);
        result.setData(null);
        return result;
    }

    /**
     * @author: 方瑞冬
     * @date: 2020/6/2 16:11
     * @since: JDK 1.8
     * 
     * @description: 指定错误返回类型
     * @param: [baseResultEnum]
     * @return: com.example.demo.result.Result<T>
     */
    public static<T> Result<T> error(BaseResultEnum baseResultEnum){
        Result<T> result = new Result<>(baseResultEnum);
        result.setData(null);
        return result;
    }
}
