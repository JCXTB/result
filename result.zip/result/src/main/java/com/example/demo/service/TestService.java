/**
 * Project Name: demo
 * File Name: TestService
 * Package Name: com.example.demo.service
 * Date: 2020/6/3 10:37
 * Author: 方瑞冬
 */
package com.example.demo.service;

import com.example.demo.entity.User;

public interface TestService {
    User getUser();
}
