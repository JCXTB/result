/**
 * Project Name: demo
 * File Name: TestServiceImpl
 * Package Name: com.example.demo.service.impl
 * Date: 2020/6/3 10:39
 * Author: 方瑞冬
 */
package com.example.demo.service.impl;

import com.example.demo.entity.User;
import com.example.demo.service.TestService;
import org.springframework.stereotype.Service;

@Service
public class TestServiceImpl implements TestService {
    @Override
    public User getUser() {
        User user = User.builder()
                .name("小明")
                .age(18)
                .build();
        return user;
    }
}
